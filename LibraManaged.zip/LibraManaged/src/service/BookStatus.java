package service;

public enum BookStatus {
    AVAILABLE, BORROWED
}