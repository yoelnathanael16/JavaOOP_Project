package service;

public enum UserRole {
    ADMIN, MEMBER
}